Website Clone Report
====================

Source URL: https://example.com
Cloned on: 2026-05-06 16:52:23
Mode: static
Depth: 1

Statistics:
  Pages cloned: 1
  Images downloaded: 0
  CSS files: 0
  JavaScript files: 0
  Other assets: 0
  Errors: 0

Folder Structure:
  /images - All images from the website
  /css - All stylesheets
  /js - All JavaScript files
  /*.html - Cloned pages
  manifest.json - Detailed clone information
